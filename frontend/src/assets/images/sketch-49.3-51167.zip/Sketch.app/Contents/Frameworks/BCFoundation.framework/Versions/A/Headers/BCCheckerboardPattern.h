//
//  Created by Aurimas Gasiulis on 15/01/2018.
//  Copyright © 2018 Bohemian Coding. All rights reserved.
//

extern void BCDrawCustomCheckerboardPatternInRect(NSRect rect,
  NSUInteger squareSize, CGContextRef context);
extern void BCDrawCheckerboardPatternInRect(NSRect rect, CGContextRef context);
